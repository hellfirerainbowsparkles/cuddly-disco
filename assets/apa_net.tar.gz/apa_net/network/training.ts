export interface TrainingPattern {
    input: number[];
    output: number[];
}