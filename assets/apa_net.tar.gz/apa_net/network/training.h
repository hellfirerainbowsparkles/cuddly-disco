#include <vector>

class TrainingPattern {
    public:
    std::vector<float> input;
    std::vector<float> output;
};
